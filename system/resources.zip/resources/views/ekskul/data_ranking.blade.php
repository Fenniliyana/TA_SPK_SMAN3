@extends('template.base')
@section('content')

<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <h5 class="card-title mb-0">Data Minat Setelah Dilakukan Perangkingan</h5> 
            </div>
           
        </div>
        
                   <div class="my-3 border-top"></div>
        <table  id="baru" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Siswa</th>
                    <th>Ekstrakulikuler</th>
                    <th>Nilai</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>
                @foreach($list_siswa as $key=>$siswa)
                    <tr>
                        <td>{{$key+1}}</td>
                        <td>{{$siswa->siswa_nama}}</td>
                        <td>@if($siswa->nilaiTinggi == null)
                            Belum Mengisi Pertanyaan
                            @else
                            @if($siswa->nilaiTinggi->status_kuota == '1')
                                <h5 class="badge rounded-pill alert-danger text-capitalize">{{$siswa->nilaiTinggi->Ekskul->nama}}</h5>
                                @else
                                <h5 class="badge rounded-pill alert-success text-capitalize">{{$siswa->nilaiTinggi->Ekskul->nama}}</h5>
                                @endif
                                 
                                
                                
                            @endif
                        </td>
                        <td>
                            @if($siswa->nilaiTinggi == null)
                            Belum Mengisi Pertanyaan
                            @else
                                @if($siswa->nilaiTinggi->status_kuota == '1')
                                <h5 class="badge rounded-pill alert-danger text-capitalize">{{$siswa->nilaiTinggi->nilai}}</h5>
                                @else
                                <h5 class="badge rounded-pill alert-success text-capitalize">{{$siswa->nilaiTinggi->nilai}}</h5>
                                @endif
                                
                                
                                
                            @endif
                        </td>
                        <td>
                            
                        @if($siswa->nilaiTinggi == null)
                            Belum Mengisi Pertanyaan
                            @else
                                @if($siswa->nilaiTinggi->status_kuota == '1')
                                <h5 class="badge rounded-pill alert-danger text-capitalize">Di Eliminasi</h5>
                                <h5 class="badge rounded-pill alert-success text-capitalize">{{$siswa->nilaiLulus->Ekskul->nama}} di Rekomendasi</h5><br>
                                <h5 class="badge rounded-pill alert-success text-capitalize">Dengan Nilai {{$siswa->nilaiLulus->peroleh_nilai}} </h5>
                                @else
                                <h5 class="badge rounded-pill alert-success text-capitalize">Di Rekomendasi</h5>
                                
                                @endif
                            @endif
                        </td>
                    </tr>
                @endforeach
            </tbody>

        </table>
    </div>
</div> 
@endsection
@section('script')
<script>
    $(function() {
    "use strict";

    $(document).ready(function() {
        $('#baru').DataTable();
      } );

});
</script>
@endsection
