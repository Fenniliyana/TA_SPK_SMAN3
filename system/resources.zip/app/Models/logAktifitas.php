<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class logAktifitas extends Model
{
    protected $table = 'log_aktifitas';
    use HasFactory;
}
