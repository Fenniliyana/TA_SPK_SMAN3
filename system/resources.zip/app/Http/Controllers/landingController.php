<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ekskul;

class landingController extends Controller
{
    function index(){
          $data['list_extra'] = ekskul::all();
        return view('landing.index',$data);
    }
}
